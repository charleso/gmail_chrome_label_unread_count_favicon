Outlook Web Access Chrome Tab Notifications
==============================

Display inbox count in your chrome tab (even when pinned)
---------------

Will show you an icon for webmail, icon with number 1-9 for new unread mail or an icon with a plus sign if more then 9 unread emails.
